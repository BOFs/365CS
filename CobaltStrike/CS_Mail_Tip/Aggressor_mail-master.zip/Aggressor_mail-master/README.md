# Aggressor_mail
beacon,aggressor-scripts,cna,cobalt-strike,email
