These scripts were created and submitted by int128. *pHEAR*
