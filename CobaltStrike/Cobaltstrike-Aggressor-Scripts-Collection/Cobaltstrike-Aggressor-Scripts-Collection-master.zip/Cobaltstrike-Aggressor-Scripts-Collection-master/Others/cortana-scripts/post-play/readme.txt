This script can be usefull for fast and very basic post-exploitation automation task.
By using it, you are able to define a command list that will be execute once
a meterpreter or shell session are created. You also have the possibility to run quickly a list
of command again a specific target. Commands are stored in a text file (one per line).

-- How to use --
Once you have load the script. a new menu item will appear on the main menu bar. you hamust choise you autorun script file from there.

example of script:

sysinfo
migrate
getsystem
hashdump
-----------
