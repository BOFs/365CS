############################################################################
#              Bot_talk.cna - by @thebenygreen                             #
#                 gacksecurity.blogspot.com                                #
############################################################################
	
This script give the voice to your cortana's bots
in this way your bot will assist you vocally. This capability will improve your experience
of pentesting or red teaming when you use Armitage or Cobalt Strike. The logic can be use
to build a virtual instructor for security training or labs.

To use this script you need to download freetts.jar
http://sourceforge.net/projects/freetts/files/

Copy this file into the lib folder and enjoy voice assistance.
Feel free to add a voice alert for any cortana's events.

Mbrola voice will be add in future release for more fun.

PS.- A demo coming very soon.
