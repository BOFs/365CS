# cobalt_strike_extension_kit
Looking for an all in one for a lot of current tradecraft?  Clone this. <br>

I do not take credit for most of this work.  A lot of this work was influenced by Outflank, Specter Ops (0xThirteen) Mainly, and seeing other Aggressor Script Repositories.  The purpose of this was to aggregate Cobalt Strike supplements used during engagements. <br>

<br>

For OPSec, you may want to provide your own binaries.  The binaries provided may get flagged by A/V, but do work in lower maturity environments and Certification lab environments.
<br>

<br>

06/25/2020 - Added more tradecraft and made Extension Kit more workflow driven.  Some items are mapped to Mitre - will expand on this in the future.
<br>
<br>
To-Do
<br>
<br>
Continue Expanding, try to implement more Offense In Depth e.g., multiple ways to do one thing.
<br>
<br>
With Offense In Depth, add items that reflect low security maturity and items that reflect higher level maturity to gauge clients.  Also may be useful in purple team engagements when using various forms of tradecraft for example - kerberoast with powershell and kerberoast with rubeus
<br>
<br>
Improve Mitre Mapping to items
<br>
<br>
Usage <br>
cd /opt/ <br>
git clone https://github.com/josephkingstone/cobaltstrike_extension_kit.git <br>
Go to cobalt strike's script manager and load csek.cna


<br>
https://github.com/GhostPack/Seatbelt <br>
https://github.com/eladshamir/Internal-Monologue <br>
https://github.com/djhohnstein/SharpWeb<br>
https://github.com/BloodHoundAD/SharpHound<br>
https://github.com/Kevin-Robertson/InveighZero<br>
https://github.com/anthemtotheego/SharpExec<br>
https://github.com/fireeye/SharPersist<br>
https://github.com/rvrsh3ll/SharpCOM<br>
https://github.com/rvrsh3ll/SharpPrinter<br>
https://github.com/rvrsh3ll/SharpFruit<br>
https://github.com/rvrsh3ll/SharpExcel4-DCOM<br>
https://github.com/fireeye/ADFSDump<br>
https://github.com/matterpreter/OffensiveCSharp<br>
https://github.com/tevora-threat/SharpView<br>
https://github.com/HunnicCyber/SharpDomainSpray<br>
https://github.com/HunnicCyber/SharpSniper<br>
https://github.com/GhostPack/Seatbelt<br>
https://github.com/GhostPack/Seatbelt<br>
https://github.com/GhostPack/SharpUp<br>
https://github.com/GhostPack/SafetyKatz<br>
https://github.com/GhostPack/SharpWMI<br>
https://github.com/FSecureLABS/SharpGPOAbuse<br>
https://github.com/GhostPack/SharpDPAPI<br>
https://github.com/0xthirteen/CleanRunMRU<br>
https://github.com/0xthirteen/SharpRDP<br>
https://github.com/Pickfordmatt/SharpLocker<br>
https://github.com/djhohnstein/SharpSearch<br>
https://github.com/slyd0g/SharpClipboard<br>
https://github.com/outflanknl/Zipper<br>
https://github.com/P1CKLES/SharpBox<br>
https://github.com/rasta-mouse/Watson<br>
https://github.com/slyd0g/SharpClipboard <br>
<br>
<br>

These Tools are not C#, but need to be incorporated into toolset<br>

https://github.com/outflanknl/Spray-AD<br>
https://github.com/outflanknl/Recon-AD<br>
https://github.com/0x09AL/RdpThief<br>
https://github.com/outflanknl/Ps-Tools<br>
