This is the repository for all publicly available aggressor scripts.

The only current public is UACBypass, whose readme can be found inside its associated folder.
