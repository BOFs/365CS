# Cobaltstrike Aggressor Script



![](https://github.com/phink-team/Cobaltstrike-MS17-010/blob/master/pic/2.png)



**ms17-010 exploit tool and scanner.**

1. Download files in cobaltstrike's root folder.
2. Import "aggressor.cna"



ms17-010 exploit tools just support win7 x64 and win2008 r2

---



pwn/Invoke-EternalBlue.ps1 from [Empire](https://github.com/EmpireProject/Empire.git)

getinfo/Invoke-EternalScan.ps1 from [@vletoux](https://github.com/vletoux/ms17-010-Scanner.git)

getinfo/Invoke-LoginPrompt.ps1 from [Empire](https://github.com/EmpireProject/Empire.git)



---

Test Picture：

![](https://github.com/phink-team/Cobaltstrike-MS17-010/blob/master/pic/1.png)



![](https://github.com/phink-team/Cobaltstrike-MS17-010/blob/master/pic/2.png)

![](pic\2.png)

![](https://github.com/phink-team/Cobaltstrike-MS17-010/blob/master/pic/3.png)



![](https://github.com/phink-team/Cobaltstrike-MS17-010/blob/master/pic/4.png)

