# SweetPotato_CS
修改的SweetPotato，使之可以用于CobaltStrike v4.0

![image-20200416161314722](https://tva1.sinaimg.cn/large/007S8ZIlgy1gdvoe062kej325f0u0jy7.jpg)