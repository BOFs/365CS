# QueueUserAPC_PPID

> queueuserapc_ppid/

BOF spawns a process of your choice under a specified parent, and injects a provided shellcode file via QueueUserAPC().

![](queueuserapc_ppid.gif)
