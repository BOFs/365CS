![](https://img.shields.io/github/license/isafe/cobaltstrike_brute?style=flat-square)
![GitHub issues](https://img.shields.io/github/issues/isafe/cobaltstrike_brute?style=flat-square)

# cobaltstrike_brute
Cobalt Strike Team Server Password Brute Forcer

usage: cs_bruter.py [-h] [-H HOSTLIST] [-P PASSWDLIST] [-p PORT] [-t THREADS]

```
optional arguments:
  -h, --help     show this help message and exit
  -H HOSTLIST    Teamserver address list file
  -P PASSWDLIST  Password list file
  -p PORT        Teamserver port
  -t THREADS     Concurrency level


