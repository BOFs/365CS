#include <stdio.h>

int crossc2_entry(int argc, char **argv) {
    printf("------------>  crossc2 dyn load!\n");
    return 1;
}
