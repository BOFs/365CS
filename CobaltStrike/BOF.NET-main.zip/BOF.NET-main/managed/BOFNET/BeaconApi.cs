﻿using System.IO;


namespace BOFNET {
    public interface BeaconApi {
        TextWriter Console { get; } 
    }
}
