# AggressorScript-UploadAndRunFrp
AggressorScript-UploadAndRunFrp/上传frpc并且运行frpc

frpc sock5代理开启，各位有其他需求的可以自行改cna脚本，frpc自行更新。
![](/pic/20190813101240.png)

## Changelogs
> 2019年8月26日
1. 修改CNA文件增加TLS加密参数
> 2019年8月27日
1. 修改CNA文件新增账户密码参数
## PS
建议 Sleep 不要调成 0s/Recommended Sleep Do not adjust to 0s

> 该项目仅供合法的渗透测试以及爱好者参考学习，请勿用于非法用途，否则自行承担相关责任！
