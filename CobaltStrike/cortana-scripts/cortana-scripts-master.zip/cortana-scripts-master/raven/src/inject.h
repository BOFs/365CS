void inject(char * buffer, int length);
void inject_process(HANDLE hProcess, char * buffer, int length);
