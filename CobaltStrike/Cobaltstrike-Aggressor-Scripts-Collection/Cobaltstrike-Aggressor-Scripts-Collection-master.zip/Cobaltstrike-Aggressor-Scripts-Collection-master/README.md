# Cobaltstrike - Aggressor Scripts Collection

I will be maintaining this repository.

The collection of tested cobaltstrike aggressor scripts.

## Big shoutout to the authors:

+ Tyler Rosonke
+ harmj0y
+ @mattifestation
+ @Und3rf10w
+ bluscreenofjeff
+ r3dQu1nn
+ @001SPARTaN
+ @vysecurity
+ MrT-F
+ @joevest
+ @AndrewChiles
+ @dubhack
+ @int128
