Adding Beacon Object Files here from TrustedSec and rvrsh3ll
