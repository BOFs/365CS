Aggressor Scripts for CobaltStrike Version 4+

- coablt_arsenal 	https://github.com/mgeeky/coablt-arsenal
