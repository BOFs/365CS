package com.eyesopencrew;

/**
 * @author Beny Green - gacksecurity.blogspot.com
 * EyesOpenCrew -
 *
 * Object representation of logs.
 */
public class Logs {
  private String logs;
  private String logscount;

    public String getLogs() {
        return logs;
    }

    public void setLogs(String logs) {
        this.logs = logs;
    }

    public String getLogscount() {
        return logscount;
    }

    public void setLogscount(String logscount) {
        this.logscount = logscount;
    }


}
