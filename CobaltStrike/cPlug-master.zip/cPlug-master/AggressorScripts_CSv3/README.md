Aggressor Scripts for CobaltStrike Version 3+

- AggressorScripts		https://github.com/bluscreenofjeff/AggressorScripts
- Arsenal 			https://github.com/Cliov/Arsenal
- cobalt_strike_extention_kit	https://github.com/josephkingstone/cobalt_strike_extention_kit
