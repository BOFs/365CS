RC loader - quickly run resource file
-----------------------------------------+

Use case: when you generate payload with veil-evasion.cna there is a handler that is also generated
          by using this script you can quickly load this handler and keep the exploitation workflow inside 
          Armitage/Cobal Strike (With msfconsole that cannot be the case).
