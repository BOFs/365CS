# cobaltstrike
现在完成的功能<Br/>
1.定位域管理员(PsLoggedo,PVEFindADUser,netview)<Br/>
2.信息收集(采用ADfind)<Br/>
3.权限维持(增加了万能密码,以及白银票据)<Br/>
4.内网扫描(nbtscan(linux/windows通用))<Br/>
5.dump数据库hash(支持mysql/mssql(快速获取数据库的hash值))<Br/>
6.增加了Everything内网搜索文件一键建立http服务进行搜索文件,并且隐藏运行图标以及图形化界面:使用方法 内网ip:49389端口(用户名:admin,密码:admin123,端口:49389)<Br/>
7.其他小功能
这个项目持续更新,这个插件只会选择在平常内网经常用到工具,不会增加多余的工具
