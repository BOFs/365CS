/*-
 *
 * extc2: open source dns over http(s)
 * transport for cs. does not use the
 * smb beacon.
 *
-*/

#pragma once

EXTERN_C
ULONG
NTAPI
RtlRandomEx( PULONG Seed );
